#!/usr/bin/env python

from core import blackowl

if __name__ == '__main__':
    blackowl.user_put()
